# Sketch Cleanup (Figma 플러그인 뼈대)

Sketch → Figma로 넘어온 파일의 반복 정리 작업을 한 번에 처리합니다. 기본은 **미리보기 → 적용** 순서입니다.

## 불러오기 (로컬 개발)
Figma 데스크톱 → Plugins → Development → **Import plugin from manifest…** → 이 폴더의 `manifest.json` 선택.
(`manifest.json`의 `id`는 임시값입니다. 공개 전에 Figma가 발급한 값으로 바꾸세요.)

## 지금 들어 있는 기능
| 작업 | 설명 |
|---|---|
| 누락 폰트 교체 | 매핑표(기본: NotoSansCJKkr→Pretendard Variable 등, UI에서 수정 가능). 섞인 폰트는 구간별로 원래 폰트·굵기 유지 |
| 슬라이스 삭제 | 점선 슬라이스. 인스턴스 안 것은 건너뜀(마스터에서 지우면 사라짐) |
| 숨김 레이어 삭제 | 컴포넌트는 제외 |
| 아이콘·로고 배경 fill 제거 | 이름이 `ic/`·`icon`·`logo`로 시작하는 컴포넌트의 자체 fill |

## 아직 없는 것 (다음 단계)
- 중복 레이어 점검(숨김 → PNG 바이트 비교 → 같을 때만 삭제)
- Sketch 마스크 모서리 보정(마스크 `cornerRadius`를 위 프레임에 적용)
- 색 빠진 아이콘 후보 목록(사람이 확인)
- 정리 전후 대표 화면 비교, 적용 결과 리포트 내보내기
